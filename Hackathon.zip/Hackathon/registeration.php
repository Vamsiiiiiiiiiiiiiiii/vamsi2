<?php
if(isset($_POST["submit"])){
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hackathon";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO details (fullname,rollno,branch,collegename,phoneno,email)
VALUES ('".$_POST["fullname"]."','".$_POST["rollno"]."','".$_POST["branch"]."','".$_POST["collegename"]."','".$_POST["phoneno"]."','".$_POST["email"]."')";

if ($conn->query($sql) === TRUE) {
echo "<script type= 'text/javascript'>alert('New record created successfully');</script>";
} else {
echo "<script type= 'text/javascript'>alert('Error: " . $sql . "<br>" . $conn->error."');</script>";
}

@header("location: thankyou.html");

$conn->close();
}
?>
